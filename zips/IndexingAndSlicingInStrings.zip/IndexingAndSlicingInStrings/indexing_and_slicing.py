greeting = 'Hello Python!'
greeting_length = len(greeting)
print(len(greeting))

# Indexing
print(greeting[1])
print(greeting[6])
print(greeting[-1])
print(greeting[12])
print(greeting[-4])

# Slicing
print(greeting[2:5])
print(greeting[6:10])
print(greeting[2:5])
print(greeting[-5:-2])
print(greeting[2:])
print(greeting[:5])
print(greeting[:])
print(greeting[::2])
print(greeting[::1])
print(greeting[1::3])
print(greeting[1:9:3])
print(greeting[::-1])